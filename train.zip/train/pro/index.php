<?php
header("location: ../");
?>
